from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):

    context = {
        'name' : 'Rashik',
        'age' : 18
    }

    return render(request, 'index.html', context)

def about(request):

    context = {
        'subjects' : ["English", "Maths", "Science", "Chemistry", "Physics"]
    }

    return render(request, 'about.html', context)

def booking(request):
    return render(request, 'booking.html')

def doctors(request):
    return render(request, 'doctors.html')

def contact(request):
    return render(request, 'contact.html')

def departments(request):
    return render(request, 'departments.html')
