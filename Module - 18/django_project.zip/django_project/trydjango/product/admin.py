from django.contrib import admin

from .models import Products, Student

# Register your models here.

admin.site.register(Products)
admin.site.register(Student)