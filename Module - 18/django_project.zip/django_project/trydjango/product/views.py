from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.

data = {
    'name' : 'Neha Bora',
    'age' : 18 
}

def home(request):
    return render(request, 'home.html', data)

def about(request):
    return render(request, 'about.html', data)

def contacts(request):
    return render(request, 'contact.html', data)