from django.db import models

# Create your models here.

class Products(models.Model):
    title = models.CharField(max_length=120)
    description = models.TextField()
    price = models.IntegerField()

class Student(models.Model):
    name = models.CharField(max_length=120)
    age = models.IntegerField()
    email = models.EmailField()
    city = models.CharField(max_length=100, null=True)

    def is_adult(self):
        if self.age >= 18:
            return True

    def __str__(self):
        return f"{self.name}, {self.age}"
